import{n as e,r as t,t as n}from"./jsx-runtime-DV-5N5dR.js";import{c as r,i,n as a,o,r as s,s as c,t as l,u}from"./index-Cn7Xxugt.js";var d=t(),f=e(),p=n();function m({onPlayLevel:e,onBack:t,language:n}){let m=n===`tr`,h=(e,t)=>m?t:e,g=e=>e?m?e.tr:e.en:``,[_,v]=(0,d.useState)(1),[y,b]=(0,d.useState)(null),[x,S]=(0,d.useState)(()=>r(c(o.CAMPAIGN,{completedLevels:{}}))),[C,w]=(0,d.useState)(()=>{try{let e=i();return e.level||s(e.totalXP||0)}catch(e){return console.error(`Failed to load progression`,e),1}});(0,d.useEffect)(()=>{let e=e=>{if((!e.key||e.key===o.CAMPAIGN)&&S(r(c(o.CAMPAIGN,{completedLevels:{}}))),!e.key||e.key===`xo-tactix-progress`||e.key===o.PROGRESSION){let e=i();w(e.level||s(e.totalXP||0))}};return window.addEventListener(`storage`,e),()=>window.removeEventListener(`storage`,e)},[]),(0,d.useEffect)(()=>{let e=e=>{e.key===`Escape`&&(y?b(null):t())};return window.addEventListener(`keydown`,e),()=>window.removeEventListener(`keydown`,e)},[y,t]);let T=Object.values(x.completedLevels||{}).reduce((e,t)=>e+(t.stars||0),0),E=e=>{if(e===1)return!0;let t=a(e);if(!t||!t.unlockCondition)return!0;if(t.unlockCondition.type===`level_complete`){let e=t.unlockCondition.value;return x.completedLevels?.[e]!==void 0}return!0},D=e=>{if(!E(e)){typeof u==`function`&&u(`error`);return}typeof u==`function`&&u(`click`);let t=a(e);b(t)},O=()=>{y&&(typeof u==`function`&&u(`click`),e(y))},k=e=>{switch(e){case`easy`:return{label:h(`EASY`,`KOLAY`),color:`#10b981`,bg:`rgba(16, 185, 129, 0.15)`,border:`rgba(16, 185, 129, 0.4)`};case`medium`:return{label:h(`MEDIUM`,`ORTA`),color:`#00f0ff`,bg:`rgba(0, 240, 255, 0.15)`,border:`rgba(0, 240, 255, 0.4)`};case`hard`:return{label:h(`HARD`,`ZOR`),color:`#f59e0b`,bg:`rgba(245, 158, 11, 0.15)`,border:`rgba(245, 158, 11, 0.4)`};case`expert`:return{label:h(`EXPERT`,`UZMAN`),color:`#ef4444`,bg:`rgba(239, 68, 68, 0.18)`,border:`rgba(239, 68, 68, 0.5)`};default:return{label:h(`NORMAL`,`NORMAL`),color:`#00f0ff`,bg:`rgba(0, 240, 255, 0.15)`,border:`rgba(0, 240, 255, 0.4)`}}},A=(0,p.jsxs)(`div`,{className:`campaign-modal-backdrop`,onClick:t,children:[(0,p.jsxs)(`div`,{className:`campaign-modal-container`,onClick:e=>e.stopPropagation(),children:[(0,p.jsxs)(`header`,{className:`campaign-top-bar`,children:[(0,p.jsxs)(`div`,{className:`campaign-title-block`,children:[(0,p.jsxs)(`span`,{className:`campaign-badge`,children:[`🧩 `,h(`PUZZLE QUEST`,`BULMACA SEFERİ`)]}),(0,p.jsx)(`h2`,{className:`campaign-main-title`,children:h(`Tactical Conquest`,`Taktiksel Sefer`)})]}),(0,p.jsxs)(`div`,{className:`campaign-stats-group`,children:[(0,p.jsxs)(`div`,{className:`campaign-stat-pill xp-pill`,title:h(`Player XP Level`,`Oyuncu TP Seviyesi`),children:[(0,p.jsx)(`span`,{className:`pill-icon`,children:`⚡`}),(0,p.jsxs)(`span`,{className:`pill-val`,children:[`LVL `,C]})]}),(0,p.jsxs)(`div`,{className:`campaign-stat-pill star-pill`,title:h(`Total Stars Collected`,`Kazanılan Yıldızlar`),children:[(0,p.jsx)(`span`,{className:`pill-icon`,children:`⭐`}),(0,p.jsxs)(`span`,{className:`pill-val`,children:[T,` / `,90]})]})]}),(0,p.jsx)(`button`,{type:`button`,className:`campaign-close-btn`,onClick:t,"aria-label":h(`Close`,`Kapat`),children:`✕`})]}),(0,p.jsxs)(`div`,{className:`campaign-scroll-body`,children:[(0,p.jsx)(`p`,{className:`campaign-subtext`,children:h(`Conquer handcrafted puzzle battles, master special powers, and collect stars to level up.`,`Özel bulmaca savaşlarını tamamla, güçleri ustalıkla kullan ve seviye atlamak için yıldızları topla.`)}),(0,p.jsx)(`div`,{className:`chapters-container`,children:l.map(e=>{let t=_===e.id,n=0,r=e.levels.length*3;e.levels.forEach(e=>{let t=x.completedLevels?.[e];t&&(n+=t.stars||0)});let i=Math.min(100,Math.round(n/r*100)),o=n===r;return(0,p.jsxs)(`div`,{className:`chapter-card ${t?`is-expanded`:``}`,children:[(0,p.jsxs)(`button`,{type:`button`,className:`chapter-header-btn`,onClick:()=>{typeof u==`function`&&u(`click`),v(t?null:e.id)},children:[(0,p.jsx)(`div`,{className:`chapter-icon-wrap`,children:e.icon}),(0,p.jsxs)(`div`,{className:`chapter-meta`,children:[(0,p.jsx)(`div`,{className:`chapter-num`,children:h(`CHAPTER ${e.id}`,`BÖLÜM ${e.id}`)}),(0,p.jsx)(`h3`,{className:`chapter-name`,children:g(e.title)})]}),(0,p.jsxs)(`div`,{className:`chapter-star-counter`,children:[(0,p.jsxs)(`span`,{className:`chapter-star-text`,children:[n,`/`,r,` ⭐`]}),(0,p.jsx)(`div`,{className:`chapter-progress-track`,children:(0,p.jsx)(`div`,{className:`chapter-progress-bar ${o?`is-gold`:``}`,style:{width:`${i}%`}})})]}),(0,p.jsx)(`span`,{className:`chapter-caret ${t?`rotated`:``}`,children:`▾`})]}),t&&(0,p.jsx)(`div`,{className:`chapter-levels-grid`,children:e.levels.map(e=>{let t=a(e),n=E(e),r=x.completedLevels?.[e],i=r?r.stars:0,o=k(t?.difficulty);return(0,p.jsxs)(`button`,{type:`button`,className:`level-card-btn ${n?``:`is-locked`} ${i>0?`is-beaten`:``}`,onClick:()=>D(e),disabled:!n,children:[(0,p.jsx)(`span`,{className:`level-difficulty-tag`,style:{color:o.color,backgroundColor:o.bg,borderColor:o.border},children:o.label}),(0,p.jsx)(`div`,{className:`level-number-display`,children:n?e:`🔒`}),(0,p.jsx)(`div`,{className:`level-stars-row`,children:[1,2,3].map(e=>(0,p.jsx)(`span`,{className:`star-symbol ${e<=i?`is-filled`:`is-empty`}`,children:`★`},e))})]},e)})})]},e.id)})})]})]}),y&&(0,p.jsx)(`div`,{className:`level-popup-backdrop`,onClick:()=>b(null),children:(0,p.jsxs)(`div`,{className:`level-popup-card`,onClick:e=>e.stopPropagation(),children:[(0,p.jsx)(`button`,{type:`button`,className:`level-popup-close`,onClick:()=>b(null),"aria-label":h(`Close`,`Kapat`),children:`✕`}),(0,p.jsxs)(`div`,{className:`level-popup-header`,children:[(0,p.jsxs)(`span`,{className:`level-popup-difficulty`,style:{color:k(y.difficulty).color,borderColor:k(y.difficulty).border,backgroundColor:k(y.difficulty).bg},children:[k(y.difficulty).label,` • `,y.boardSize,`x`,y.boardSize]}),(0,p.jsxs)(`h3`,{className:`level-popup-title`,children:[`#`,y.id,` `,g(y.title)]}),(0,p.jsx)(`p`,{className:`level-popup-desc`,children:g(y.description)})]}),(0,p.jsxs)(`div`,{className:`level-conditions-box`,children:[(0,p.jsx)(`div`,{className:`conditions-title`,children:h(`Star Objectives`,`Yıldız Hedefleri`)}),(0,p.jsxs)(`div`,{className:`condition-row`,children:[(0,p.jsx)(`span`,{className:`cond-star`,children:`★☆☆`}),(0,p.jsx)(`span`,{className:`cond-desc`,children:h(`Victory: Complete the match`,`Zafer: Maçı tamamlayıp kazan`)})]}),y.stars?.two&&(0,p.jsxs)(`div`,{className:`condition-row`,children:[(0,p.jsx)(`span`,{className:`cond-star`,children:`★★☆`}),(0,p.jsx)(`span`,{className:`cond-desc`,children:y.stars.two.condition===`win_in_moves`?h(`Win in ≤ ${y.stars.two.value} moves`,`En fazla ${y.stars.two.value} hamlede kazan`):y.stars.two.condition===`power_used`?h(`Win using ${y.stars.two.value} power`,`${y.stars.two.value} gücünü kullanarak kazan`):y.stars.two.condition===`score_above`?h(`Score ≥ ${y.stars.two.value} points`,`En az ${y.stars.two.value} puan kazan`):h(`Tactical mastery objective`,`Taktiksel ustalık hedefi`)})]}),y.stars?.three&&(0,p.jsxs)(`div`,{className:`condition-row`,children:[(0,p.jsx)(`span`,{className:`cond-star`,children:`★★★`}),(0,p.jsx)(`span`,{className:`cond-desc`,children:y.stars.three.condition===`win_in_moves`?h(`Speed master: Win in ≤ ${y.stars.three.value} moves`,`Hız ustası: En fazla ${y.stars.three.value} hamlede kazan`):y.stars.three.condition===`score_above`?h(`High scorer: Score ≥ ${y.stars.three.value} points`,`Yüksek skor: En az ${y.stars.three.value} puan kazan`):h(`Grandmaster objective`,`Büyük usta hedefi`)})]})]}),y.reward&&(0,p.jsxs)(`div`,{className:`level-reward-row`,children:[(0,p.jsx)(`span`,{className:`reward-icon`,children:`🎁`}),(0,p.jsxs)(`span`,{className:`reward-info`,children:[h(`Reward:`,`Ödül:`),` `,(0,p.jsx)(`strong`,{children:y.reward.type===`skin`?m?`Tema: ${y.reward.value.toUpperCase()}`:`Theme: ${y.reward.value.toUpperCase()}`:y.reward.type===`power`?m?`Güç: ${y.reward.value.toUpperCase()}`:`Power: ${y.reward.value.toUpperCase()}`:`+${y.reward.value} XP`})]})]}),x.completedLevels?.[y.id]&&(0,p.jsxs)(`div`,{className:`best-score-banner`,children:[(0,p.jsxs)(`span`,{children:[`🏆 `,h(`Current Best:`,`En İyi Derecen:`)]}),(0,p.jsxs)(`strong`,{children:[x.completedLevels[y.id].stars,` / 3 ⭐`]})]}),(0,p.jsxs)(`button`,{type:`button`,className:`launch-mission-btn`,onClick:O,children:[(0,p.jsx)(`span`,{className:`launch-glow`}),(0,p.jsxs)(`span`,{className:`launch-text`,children:[`⚡ `,h(`START BATTLE`,`SAVAŞA BAŞLA`)]})]})]})}),(0,p.jsx)(`style`,{children:`
        .campaign-modal-backdrop {
          position: fixed;
          inset: 0;
          z-index: 9999;
          display: grid;
          place-items: center;
          background: rgba(3, 6, 15, 0.9);
          backdrop-filter: blur(14px);
          -webkit-backdrop-filter: blur(14px);
          padding: 16px;
          box-sizing: border-box;
          animation: campaignFadeIn 0.22s ease-out;
        }

        @keyframes campaignFadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .campaign-modal-container {
          position: relative;
          width: min(720px, 95vw);
          max-height: min(88vh, 760px);
          margin: auto;
          background: linear-gradient(180deg, rgba(17, 24, 39, 0.98) 0%, rgba(10, 14, 26, 0.99) 100%);
          border: 1px solid rgba(168, 85, 247, 0.35);
          border-radius: 24px;
          box-shadow: 0 25px 60px rgba(0, 0, 0, 0.85), 0 0 45px rgba(168, 85, 247, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.12);
          display: flex;
          flex-direction: column;
          overflow: hidden;
          box-sizing: border-box;
          animation: campaignPopUp 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes campaignPopUp {
          from { transform: scale(0.95) translateY(16px); opacity: 0; }
          to { transform: scale(1) translateY(0); opacity: 1; }
        }

        .campaign-top-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 24px;
          border-bottom: 1px solid rgba(0, 240, 255, 0.15);
          background: rgba(15, 23, 42, 0.6);
          gap: 12px;
        }

        .campaign-badge {
          display: inline-block;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 1.5px;
          color: #a855f7;
          text-transform: uppercase;
          margin-bottom: 2px;
        }

        .campaign-main-title {
          margin: 0;
          font-size: 1.35rem;
          font-weight: 800;
          color: #ffffff;
          letter-spacing: 0.5px;
          text-shadow: 0 0 16px rgba(0, 240, 255, 0.4);
        }

        .campaign-stats-group {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-left: auto;
        }

        .campaign-stat-pill {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          border-radius: 999px;
          font-size: 0.85rem;
          font-weight: 700;
          border: 1px solid;
        }

        .xp-pill {
          background: rgba(168, 85, 247, 0.15);
          border-color: rgba(168, 85, 247, 0.4);
          color: #c084fc;
        }

        .star-pill {
          background: rgba(245, 158, 11, 0.15);
          border-color: rgba(245, 158, 11, 0.4);
          color: #fbbf24;
        }

        .campaign-close-btn {
          width: 34px;
          height: 34px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.2);
          background: rgba(255, 255, 255, 0.08);
          color: #ffffff;
          display: grid;
          place-items: center;
          cursor: pointer;
          font-size: 14px;
          transition: all 0.18s ease;
        }

        .campaign-close-btn:hover {
          background: rgba(239, 68, 68, 0.3);
          border-color: rgba(239, 68, 68, 0.6);
          color: #ff8888;
          transform: rotate(90deg);
        }

        .campaign-scroll-body {
          padding: 20px 24px 28px;
          overflow-y: auto;
          scrollbar-width: thin;
          scrollbar-color: rgba(0, 240, 255, 0.4) transparent;
        }

        .campaign-scroll-body::-webkit-scrollbar {
          width: 6px;
        }
        .campaign-scroll-body::-webkit-scrollbar-thumb {
          background: rgba(0, 240, 255, 0.35);
          border-radius: 3px;
        }

        .campaign-subtext {
          margin: 0 0 16px;
          font-size: 0.9rem;
          color: #94a3b8;
          line-height: 1.45;
        }

        .chapters-container {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .chapter-card {
          background: rgba(15, 23, 42, 0.7);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 16px;
          overflow: hidden;
          transition: border-color 0.2s, box-shadow 0.2s;
        }

        .chapter-card.is-expanded {
          border-color: rgba(0, 240, 255, 0.45);
          box-shadow: 0 0 24px rgba(0, 240, 255, 0.1);
        }

        .chapter-header-btn {
          width: 100%;
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 14px 18px;
          background: transparent;
          border: none;
          color: #fff;
          cursor: pointer;
          text-align: left;
          transition: background 0.18s;
        }

        .chapter-header-btn:hover {
          background: rgba(0, 240, 255, 0.05);
        }

        .chapter-icon-wrap {
          font-size: 1.6rem;
          line-height: 1;
          filter: drop-shadow(0 0 8px rgba(168, 85, 247, 0.5));
        }

        .chapter-meta {
          flex: 1;
          min-width: 0;
        }

        .chapter-num {
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 1.2px;
          color: #38bdf8;
          text-transform: uppercase;
        }

        .chapter-name {
          margin: 2px 0 0;
          font-size: 1.05rem;
          font-weight: 700;
          color: #f8fafc;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .chapter-star-counter {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 4px;
        }

        .chapter-star-text {
          font-size: 0.8rem;
          font-weight: 700;
          color: #fbbf24;
        }

        .chapter-progress-track {
          width: 80px;
          height: 6px;
          background: rgba(255, 255, 255, 0.1);
          border-radius: 999px;
          overflow: hidden;
        }

        .chapter-progress-bar {
          height: 100%;
          background: linear-gradient(90deg, #00f0ff, #38bdf8);
          border-radius: 999px;
          transition: width 0.3s ease;
        }

        .chapter-progress-bar.is-gold {
          background: linear-gradient(90deg, #f59e0b, #fbbf24);
          box-shadow: 0 0 8px rgba(245, 158, 11, 0.8);
        }

        .chapter-caret {
          font-size: 1.1rem;
          color: #64748b;
          transition: transform 0.22s ease;
        }

        .chapter-caret.rotated {
          transform: rotate(180deg);
          color: #00f0ff;
        }

        .chapter-levels-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
          gap: 10px;
          padding: 14px 18px 18px;
          background: rgba(4, 6, 14, 0.4);
          border-top: 1px solid rgba(255, 255, 255, 0.06);
        }

        .level-card-btn {
          position: relative;
          background: rgba(30, 41, 59, 0.5);
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 14px;
          padding: 14px 8px 10px;
          display: flex;
          flex-direction: column;
          align-items: center;
          cursor: pointer;
          transition: all 0.18s ease;
        }

        .level-card-btn:hover:not(:disabled) {
          border-color: #00f0ff;
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(0, 240, 255, 0.2);
          background: rgba(30, 41, 59, 0.85);
        }

        .level-card-btn:disabled {
          opacity: 0.45;
          cursor: not-allowed;
          filter: grayscale(80%);
        }

        .level-card-btn.is-beaten {
          border-color: rgba(245, 158, 11, 0.4);
          background: rgba(245, 158, 11, 0.05);
        }

        .level-difficulty-tag {
          position: absolute;
          top: 6px;
          right: 6px;
          font-size: 8px;
          font-weight: 800;
          padding: 2px 5px;
          border-radius: 6px;
          border: 1px solid;
          letter-spacing: 0.5px;
        }

        .level-number-display {
          font-size: 1.5rem;
          font-weight: 800;
          color: #ffffff;
          margin: 6px 0 4px;
          text-shadow: 0 0 10px rgba(0, 240, 255, 0.3);
        }

        .level-stars-row {
          display: flex;
          gap: 2px;
          font-size: 0.95rem;
        }

        .star-symbol.is-filled {
          color: #fbbf24;
          filter: drop-shadow(0 0 3px rgba(245, 158, 11, 0.9));
        }

        .star-symbol.is-empty {
          color: rgba(255, 255, 255, 0.18);
        }

        /* Popup Sub-modal */
        .level-popup-backdrop {
          position: fixed;
          inset: 0;
          z-index: 10001;
          display: grid;
          place-items: center;
          background: rgba(2, 4, 12, 0.85);
          backdrop-filter: blur(10px);
          padding: 16px;
          animation: campaignFadeIn 0.18s ease-out;
        }

        .level-popup-card {
          position: relative;
          width: min(440px, 94vw);
          margin: auto;
          background: #0f172a;
          border: 1.5px solid #a855f7;
          border-radius: 22px;
          padding: 24px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.85), 0 0 35px rgba(168, 85, 247, 0.3);
          animation: campaignPopUp 0.22s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .level-popup-close {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 30px;
          height: 30px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.15);
          background: rgba(255, 255, 255, 0.08);
          color: #fff;
          cursor: pointer;
          display: grid;
          place-items: center;
        }

        .level-popup-header {
          margin-bottom: 16px;
        }

        .level-popup-difficulty {
          display: inline-block;
          font-size: 10px;
          font-weight: 800;
          padding: 3px 8px;
          border-radius: 8px;
          border: 1px solid;
          margin-bottom: 8px;
        }

        .level-popup-title {
          margin: 0 0 6px;
          font-size: 1.3rem;
          font-weight: 800;
          color: #fff;
        }

        .level-popup-desc {
          margin: 0;
          font-size: 0.9rem;
          color: #94a3b8;
          line-height: 1.4;
        }

        .level-conditions-box {
          background: rgba(0, 240, 255, 0.05);
          border: 1px solid rgba(0, 240, 255, 0.2);
          border-radius: 12px;
          padding: 12px 16px;
          margin-bottom: 16px;
        }

        .conditions-title {
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 1px;
          text-transform: uppercase;
          color: #38bdf8;
          margin-bottom: 8px;
        }

        .condition-row {
          display: flex;
          align-items: center;
          gap: 10px;
          font-size: 0.85rem;
          margin-bottom: 6px;
        }

        .condition-row:last-child {
          margin-bottom: 0;
        }

        .cond-star {
          font-size: 0.85rem;
          color: #fbbf24;
          font-weight: 700;
          min-width: 36px;
        }

        .cond-desc {
          color: #e2e8f0;
        }

        .level-reward-row {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 12px;
          background: rgba(168, 85, 247, 0.12);
          border: 1px solid rgba(168, 85, 247, 0.35);
          border-radius: 10px;
          font-size: 0.85rem;
          color: #c084fc;
          margin-bottom: 12px;
        }

        .level-reward-row strong {
          color: #f8fafc;
        }

        .best-score-banner {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 10px 14px;
          background: rgba(245, 158, 11, 0.12);
          border: 1px solid rgba(245, 158, 11, 0.35);
          border-radius: 10px;
          font-size: 0.85rem;
          color: #fbbf24;
          margin-bottom: 16px;
        }

        .launch-mission-btn {
          position: relative;
          width: 100%;
          padding: 14px;
          border-radius: 14px;
          border: none;
          background: linear-gradient(135deg, #00f0ff 0%, #0284c7 100%);
          color: #030712;
          font-size: 1.05rem;
          font-weight: 900;
          letter-spacing: 1px;
          cursor: pointer;
          overflow: hidden;
          transition: transform 0.16s ease, box-shadow 0.16s ease;
          box-shadow: 0 4px 20px rgba(0, 240, 255, 0.4);
        }

        .launch-mission-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 28px rgba(0, 240, 255, 0.6);
        }

        .launch-mission-btn:active {
          transform: translateY(0);
        }

        @media (max-width: 500px) {
          .campaign-top-bar {
            padding: 14px 16px;
          }
          .campaign-scroll-body {
            padding: 16px;
          }
          .chapter-levels-grid {
            grid-template-columns: repeat(auto-fill, minmax(85px, 1fr));
            gap: 8px;
            padding: 10px;
          }
          .level-number-display {
            font-size: 1.25rem;
          }
        }
      `})]});return typeof document<`u`?(0,f.createPortal)(A,document.body):A}export{m as default};