import{n as e,r as t,t as n}from"./jsx-runtime-DV-5N5dR.js";import{c as r,d as i,s as a,u as o}from"./index--8LujVWA.js";var s=t(),c=e(),l=n(),u={en:{title:`Daily Mission`,subtitle:`New tactical challenge every 24 hours`,playToday:`PLAY TODAY'S MISSION`,completed:`Mission Accomplished!`,nextIn:`Next reset in`,streak:`Active Streak`,days:`Days`,history:`7-Day History`,reward:`+500 XP & Streak Bonus`,back:`Close`,monday_title:`Speed Challenge`,monday_desc:`Win the game in as few moves as possible.`,tuesday_title:`Power Master`,tuesday_desc:`Win the game using your specialized powers.`,wednesday_title:`Expanded Battlefield`,wednesday_desc:`Dominate the 4x4 / 5x5 grid against elite AI.`,thursday_title:`Tactical Multiplier`,thursday_desc:`Utilize multiplier cells to outscore and defeat your opponent.`,friday_title:`Survival Protocol`,friday_desc:`Survive against relentless AI pressure.`,saturday_title:`Pure Tactical Skill`,saturday_desc:`No powers allowed. Pure mind game versus Expert AI.`,sunday_title:`Cosmic Chaos`,sunday_desc:`Unpredictable rules and extreme board dynamics.`},tr:{title:`Günün Görevi`,subtitle:`Her 24 saatte bir yeni taktiksel meydan okuma`,playToday:`GÜNÜN GÖREVİNİ OYNA`,completed:`Görev Tamamlandı!`,nextIn:`Yeni göreve kalan:`,streak:`Kazanma Serisi`,days:`Gün`,history:`7 Günlük Takip`,reward:`+500 TP & Seri Bonusu`,back:`Kapat`,monday_title:`Hız Görevi`,monday_desc:`Oyunu en az hamle ile hızlıca kazan.`,tuesday_title:`Güç Ustası`,tuesday_desc:`Özel güçleri kullanarak rakibi mağlup et.`,wednesday_title:`Büyük Savaş Alanı`,wednesday_desc:`Genişletilmiş 4x4 / 5x5 tahtada yapay zekayı alt et.`,thursday_title:`Taktiksel Çarpan`,thursday_desc:`Çarpanlı hücreleri kullanarak rakibi mağlup et ve zafere ulaş.`,friday_title:`Hayatta Kalma Protokolü`,friday_desc:`Agresif yapay zekaya karşı diren ve kazan.`,saturday_title:`Saf Taktiksel Yetenek`,saturday_desc:`Güç yok. Uzman yapay zekaya karşı zeka savaşı.`,sunday_title:`Kozmik Kaos`,sunday_desc:`Öngörülemez kurallar ve dinamik tahta düzeni.`}};function d(e){return function(){var t=e+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}}function f(e){let t=0;for(let n=0;n<e.length;n++)t=(t<<5)-t+e.charCodeAt(n),t|=0;return t}function p(){let e=new Date,t=e.getFullYear()+`-`+String(e.getMonth()+1).padStart(2,`0`)+`-`+String(e.getDate()).padStart(2,`0`),n=d(f(t)),r=e.getDay(),i={id:`daily-${t}`,isDaily:!0,date:t,title:{en:`Daily Challenge`,tr:`Günün Görevi`},reward:{type:`xp`,value:500}},a=[`bomb`,`shield`,`freeze`,`vampire`,`trap`],o=[`balanced`,`aggressive`,`defensive`,`chaotic`],s=(e=>{switch(e){case 1:return`monday`;case 2:return`tuesday`;case 3:return`wednesday`;case 4:return`thursday`;case 5:return`friday`;case 6:return`saturday`;case 0:return`sunday`;default:return`monday`}})(r);if(i.dayType=s,i.title={en:u.en[`${s}_title`]||`Daily Challenge`,tr:u.tr[`${s}_title`]||`Günün Görevi`},i.description={en:u.en[`${s}_desc`]||`Complete today's challenge to earn rewards`,tr:u.tr[`${s}_desc`]||`Ödülü kazanmak için günün görevini tamamla`},r===1)i.type=`challenge`,i.boardSize=3,i.winLength=3,i.difficulty=`medium`,i.constraints={maxMoves:7+Math.floor(n()*4)},i.aiPersonality=o[Math.floor(n()*o.length)];else if(r===2){i.type=`win`,i.boardSize=3,i.winLength=3,i.difficulty=`medium`;let e=a[Math.floor(n()*a.length)];i.constraints={requirePower:e},i.initialPowers={bomb:0,shield:0,freeze:0,vampire:0,trap:0},i.initialPowers[e]=2+Math.floor(n()*2),i.aiPersonality=`balanced`}else r===3?(i.type=`win`,i.boardSize=n()>.5?4:5,i.winLength=i.boardSize===4||n()>.5?4:5,i.difficulty=`hard`,i.constraints={},i.aiPersonality=`aggressive`):r===4?(i.type=`win`,i.boardSize=3,i.winLength=3,i.difficulty=`hard`,i.constraints={requireMultiplier:!0},i.initialBoard=null,i.initialPowers=null,i.aiPersonality=`defensive`):r===5?(i.type=`survival`,i.boardSize=3,i.winLength=3,i.difficulty=`hard`,i.constraints={},i.aiPersonality=`aggressive`):r===6?(i.type=`win`,i.boardSize=3,i.winLength=3,i.difficulty=`expert`,i.constraints={noPowers:!0},i.initialPowers={bomb:0,shield:0,freeze:0,vampire:0,trap:0},i.aiPersonality=`balanced`):(i.type=[`win`,`challenge`,`survival`][Math.floor(n()*3)],i.boardSize=3+Math.floor(n()*2),i.winLength=i.boardSize,i.difficulty=[`medium`,`hard`,`expert`][Math.floor(n()*3)],i.constraints={},i.aiPersonality=o[Math.floor(n()*o.length)]);return i}function m(e){try{let t=o(r(a.DAILY,{}));if(e&&t.history&&t.history[e])return!!t.history[e].completed;let n=new Date,i=n.getFullYear()+`-`+String(n.getMonth()+1).padStart(2,`0`)+`-`+String(n.getDate()).padStart(2,`0`);return t.lastCompleted===i}catch{return!1}}function h({onPlayChallenge:e,onBack:t,language:n=`en`}){let[d,f]=(0,s.useState)(``),[m,h]=(0,s.useState)(()=>o(r(a.DAILY,{streak:0,history:{},lastCompleted:null}))),g=u[n]||u.en,_=p(),v=n===`tr`;(0,s.useEffect)(()=>{let e=e=>{(!e.key||e.key===a.DAILY)&&h(o(r(a.DAILY,{streak:0,history:{},lastCompleted:null})))};return window.addEventListener(`storage`,e),()=>window.removeEventListener(`storage`,e)},[]),(0,s.useEffect)(()=>{let e=e=>{e.key===`Escape`&&t()};return window.addEventListener(`keydown`,e),()=>window.removeEventListener(`keydown`,e)},[t]),(0,s.useEffect)(()=>{let e=()=>{let e=new Date,t=new Date(e);t.setHours(24,0,0,0);let n=t-e,r=Math.floor(n/(1e3*60*60)%24),i=Math.floor(n/1e3/60%60),a=Math.floor(n/1e3%60);f(`${r.toString().padStart(2,`0`)}:${i.toString().padStart(2,`0`)}:${a.toString().padStart(2,`0`)}`)};e();let t=setInterval(e,1e3);return()=>clearInterval(t)},[]);let y=m.lastCompleted===_.date||!!m.history?.[_.date]?.completed,b=(t=!1)=>{typeof i==`function`&&i(`click`),e(t||y?{..._,isPractice:!0}:_)},x=()=>{typeof i==`function`&&i(`click`),t()},S=`${_.dayType}_title`,C=`${_.dayType}_desc`,w=[];for(let e=6;e>=0;e--){let t=new Date;t.setDate(t.getDate()-e);let r=t.getFullYear()+`-`+String(t.getMonth()+1).padStart(2,`0`)+`-`+String(t.getDate()).padStart(2,`0`),i=e>0,a=e===0,o=`none`;m.history&&m.history[r]&&m.history[r].completed?o=`completed`:i&&(o=`missed`),w.push({date:r,status:o,isToday:a,label:t.toLocaleDateString(n===`tr`?`tr-TR`:`en-US`,{weekday:`short`})})}let T=(0,l.jsxs)(`div`,{className:`daily-modal-backdrop`,onClick:x,children:[(0,l.jsxs)(`div`,{className:`daily-modal-card`,onClick:e=>e.stopPropagation(),children:[(0,l.jsxs)(`div`,{className:`daily-header-bar`,children:[(0,l.jsxs)(`div`,{className:`daily-tag-badge`,children:[(0,l.jsx)(`span`,{className:`daily-badge-dot`}),(0,l.jsx)(`span`,{children:v?`GÜNLÜK ETKİNLİK`:`DAILY EVENT`})]}),(0,l.jsx)(`h2`,{className:`daily-modal-title`,children:g.title}),(0,l.jsx)(`p`,{className:`daily-modal-subtitle`,children:g.subtitle}),(0,l.jsx)(`button`,{type:`button`,className:`daily-modal-close-btn`,onClick:x,"aria-label":g.back,children:`✕`})]}),(0,l.jsxs)(`div`,{className:`daily-scroll-area`,children:[(0,l.jsxs)(`div`,{className:`daily-mission-card`,children:[(0,l.jsxs)(`div`,{className:`daily-timer-pill`,children:[(0,l.jsx)(`span`,{className:`timer-sand`,children:`⏳`}),(0,l.jsxs)(`span`,{className:`timer-val`,children:[g.nextIn,` `,(0,l.jsx)(`strong`,{children:d})]})]}),(0,l.jsxs)(`div`,{className:`mission-content`,children:[(0,l.jsxs)(`div`,{className:`mission-badge-row`,children:[(0,l.jsxs)(`span`,{className:`mission-chip board-chip`,children:[_.boardSize,`x`,_.boardSize]}),(0,l.jsx)(`span`,{className:`mission-chip diff-chip`,children:_.difficulty?.toUpperCase()}),_.constraints?.maxMoves&&(0,l.jsxs)(`span`,{className:`mission-chip constraint-chip`,children:[`MAX `,_.constraints.maxMoves,` `,v?`HAMLE`:`MOVES`]})]}),(0,l.jsx)(`h3`,{className:`challenge-headline`,children:g[S]}),(0,l.jsx)(`p`,{className:`challenge-paragraph`,children:g[C]}),(0,l.jsxs)(`div`,{className:`reward-glow-badge`,children:[(0,l.jsx)(`span`,{className:`reward-gem`,children:`💎`}),(0,l.jsx)(`span`,{className:`reward-text`,children:g.reward})]})]}),y?(0,l.jsxs)(`div`,{className:`completed-action-group`,children:[(0,l.jsxs)(`div`,{className:`completed-state-banner`,children:[(0,l.jsx)(`span`,{className:`check-icon`,children:`✓`}),(0,l.jsxs)(`div`,{className:`completed-text-wrap`,children:[(0,l.jsx)(`h4`,{children:g.completed}),(0,l.jsx)(`p`,{children:v?`Ödül alındı! Yarın yeni bir taktiksel görev seni bekliyor.`:`Reward claimed! Return tomorrow for a new tactical challenge.`})]})]}),(0,l.jsxs)(`button`,{type:`button`,className:`daily-practice-button`,onClick:()=>b(!0),children:[`🎯 `,v?`Alıştırma Yap (Tekrar Oyna)`:`Practice Mode (Replay)`]})]}):(0,l.jsxs)(`button`,{type:`button`,className:`daily-cta-button`,onClick:()=>b(!1),children:[(0,l.jsx)(`span`,{className:`cta-glow-pulse`}),(0,l.jsxs)(`span`,{className:`cta-label`,children:[`⚡ `,g.playToday]})]})]}),(0,l.jsxs)(`div`,{className:`daily-streak-card`,children:[(0,l.jsxs)(`div`,{className:`streak-title-row`,children:[(0,l.jsxs)(`div`,{className:`streak-flame-wrap`,children:[(0,l.jsx)(`span`,{className:`flame-icon`,children:`🔥`}),(0,l.jsxs)(`div`,{className:`streak-stat-info`,children:[(0,l.jsx)(`span`,{className:`streak-header-label`,children:g.streak}),(0,l.jsxs)(`span`,{className:`streak-counter-value`,children:[m.streak||0,` `,g.days]})]})]}),(0,l.jsx)(`span`,{className:`streak-sub-info`,children:v?`Her gün oyna, TP bonusunu katla!`:`Play daily to stack XP bonuses!`})]}),(0,l.jsx)(`div`,{className:`daily-timeline-tracker`,children:w.map((e,t)=>(0,l.jsxs)(`div`,{className:`timeline-day ${e.status} ${e.isToday?`is-current-day`:``}`,title:`${e.date}: ${e.status}`,children:[(0,l.jsx)(`span`,{className:`timeline-day-label`,children:e.label}),(0,l.jsxs)(`div`,{className:`timeline-dot-circle`,children:[e.status===`completed`&&`✓`,e.status===`missed`&&`✕`]})]},t))})]})]})]}),(0,l.jsx)(`style`,{children:`
        .daily-modal-backdrop {
          position: fixed;
          inset: 0;
          z-index: 9999;
          display: grid;
          place-items: center;
          background: rgba(3, 6, 15, 0.9);
          backdrop-filter: blur(14px);
          -webkit-backdrop-filter: blur(14px);
          padding: 16px;
          box-sizing: border-box;
          animation: dailyFadeIn 0.22s ease-out;
        }

        @keyframes dailyFadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .daily-modal-card {
          position: relative;
          width: min(560px, 95vw);
          max-height: min(88vh, 720px);
          margin: auto;
          background: linear-gradient(180deg, rgba(20, 24, 38, 0.98) 0%, rgba(11, 14, 25, 0.99) 100%);
          border: 1px solid rgba(245, 158, 11, 0.4);
          border-radius: 24px;
          box-shadow: 0 25px 60px rgba(0, 0, 0, 0.85), 0 0 45px rgba(245, 158, 11, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.12);
          display: flex;
          flex-direction: column;
          overflow: hidden;
          box-sizing: border-box;
          animation: dailyPopUp 0.22s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes dailyPopUp {
          from { transform: scale(0.95) translateY(16px); opacity: 0; }
          to { transform: scale(1) translateY(0); opacity: 1; }
        }

        .daily-header-bar {
          position: relative;
          padding: 22px 24px 16px;
          text-align: center;
          border-bottom: 1px solid rgba(245, 158, 11, 0.15);
          background: rgba(15, 23, 42, 0.5);
        }

        .daily-tag-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 10px;
          background: rgba(245, 158, 11, 0.12);
          border: 1px solid rgba(245, 158, 11, 0.35);
          border-radius: 999px;
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 1.5px;
          color: #fbbf24;
          margin-bottom: 6px;
        }

        .daily-badge-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #fbbf24;
          box-shadow: 0 0 6px #fbbf24;
          animation: dailyPulseDot 1.8s infinite;
        }

        @keyframes dailyPulseDot {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(0.8); }
        }

        .daily-modal-title {
          margin: 0;
          font-size: 1.65rem;
          font-weight: 900;
          color: #ffffff;
          letter-spacing: 0.5px;
          text-shadow: 0 0 16px rgba(245, 158, 11, 0.4);
        }

        .daily-modal-subtitle {
          margin: 4px 0 0;
          font-size: 0.9rem;
          color: #94a3b8;
        }

        .daily-modal-close-btn {
          position: absolute;
          top: 16px;
          right: 16px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.2);
          background: rgba(255, 255, 255, 0.08);
          color: #ffffff;
          display: grid;
          place-items: center;
          cursor: pointer;
          font-size: 14px;
          transition: all 0.18s ease;
        }

        .daily-modal-close-btn:hover {
          background: rgba(239, 68, 68, 0.3);
          border-color: rgba(239, 68, 68, 0.6);
          color: #ff8888;
          transform: rotate(90deg);
        }

        .daily-scroll-area {
          padding: 20px 24px 28px;
          overflow-y: auto;
          scrollbar-width: thin;
          scrollbar-color: rgba(245, 158, 11, 0.4) transparent;
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .daily-scroll-area::-webkit-scrollbar {
          width: 6px;
        }
        .daily-scroll-area::-webkit-scrollbar-thumb {
          background: rgba(245, 158, 11, 0.35);
          border-radius: 3px;
        }

        /* Mission Card */
        .daily-mission-card {
          position: relative;
          background: linear-gradient(135deg, rgba(30, 41, 59, 0.7) 0%, rgba(15, 23, 42, 0.8) 100%);
          border: 1px solid rgba(245, 158, 11, 0.25);
          border-radius: 20px;
          padding: 20px;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
        }

        .daily-timer-pill {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 10px;
          background: rgba(0, 0, 0, 0.4);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 999px;
          font-size: 0.8rem;
          color: #cbd5e1;
          margin-bottom: 14px;
        }

        .timer-val strong {
          color: #38bdf8;
          font-family: monospace;
          font-size: 0.9rem;
        }

        .mission-badge-row {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          margin-bottom: 10px;
        }

        .mission-chip {
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 0.8px;
          padding: 3px 8px;
          border-radius: 6px;
          text-transform: uppercase;
        }

        .board-chip {
          background: rgba(56, 189, 248, 0.15);
          border: 1px solid rgba(56, 189, 248, 0.35);
          color: #38bdf8;
        }

        .diff-chip {
          background: rgba(245, 158, 11, 0.15);
          border: 1px solid rgba(245, 158, 11, 0.35);
          color: #fbbf24;
        }

        .constraint-chip {
          background: rgba(168, 85, 247, 0.15);
          border: 1px solid rgba(168, 85, 247, 0.35);
          color: #c084fc;
        }

        .challenge-headline {
          margin: 0 0 8px;
          font-size: 1.35rem;
          font-weight: 800;
          color: #ffffff;
        }

        .challenge-paragraph {
          margin: 0 0 16px;
          font-size: 0.95rem;
          color: #94a3b8;
          line-height: 1.45;
        }

        .reward-glow-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 8px 14px;
          background: rgba(245, 158, 11, 0.12);
          border: 1px solid rgba(245, 158, 11, 0.35);
          border-radius: 12px;
          font-size: 0.88rem;
          font-weight: 700;
          color: #fbbf24;
          margin-bottom: 18px;
        }

        .daily-cta-button {
          position: relative;
          width: 100%;
          padding: 16px;
          border-radius: 16px;
          border: none;
          background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
          color: #05070e;
          font-size: 1.05rem;
          font-weight: 900;
          letter-spacing: 1px;
          cursor: pointer;
          overflow: hidden;
          transition: transform 0.16s ease, box-shadow 0.16s ease;
          box-shadow: 0 6px 24px rgba(245, 158, 11, 0.4);
        }

        .daily-cta-button:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 32px rgba(245, 158, 11, 0.6);
        }

        .daily-cta-button:active {
          transform: translateY(0);
        }

        .completed-state-banner {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 14px 18px;
          background: rgba(16, 185, 129, 0.12);
          border: 1px solid rgba(16, 185, 129, 0.35);
          border-radius: 14px;
        }

        .check-icon {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background: #10b981;
          color: #05070e;
          display: grid;
          place-items: center;
          font-size: 1.2rem;
          font-weight: 900;
        }

        .completed-text-wrap h4 {
          margin: 0;
          font-size: 1rem;
          font-weight: 800;
          color: #34d399;
        }

        .completed-text-wrap p {
          margin: 2px 0 0;
          font-size: 0.8rem;
          color: #94a3b8;
        }

        .completed-action-group {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .daily-practice-button {
          width: 100%;
          padding: 12px;
          border-radius: 14px;
          border: 1px solid rgba(56, 189, 248, 0.4);
          background: rgba(56, 189, 248, 0.12);
          color: #38bdf8;
          font-size: 0.95rem;
          font-weight: 800;
          cursor: pointer;
          transition: all 0.18s ease;
        }

        .daily-practice-button:hover {
          background: rgba(56, 189, 248, 0.25);
          border-color: #38bdf8;
          transform: translateY(-1px);
        }

        /* Streak Card */
        .daily-streak-card {
          background: rgba(15, 23, 42, 0.6);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 18px;
          padding: 16px 20px;
        }

        .streak-title-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          flex-wrap: wrap;
          gap: 10px;
          margin-bottom: 14px;
        }

        .streak-flame-wrap {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .flame-icon {
          font-size: 1.8rem;
          filter: drop-shadow(0 0 8px rgba(245, 158, 11, 0.6));
        }

        .streak-stat-info {
          display: flex;
          flex-direction: column;
        }

        .streak-header-label {
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 1px;
          text-transform: uppercase;
          color: #94a3b8;
        }

        .streak-counter-value {
          font-size: 1.15rem;
          font-weight: 900;
          color: #fbbf24;
        }

        .streak-sub-info {
          font-size: 0.8rem;
          color: #64748b;
        }

        .daily-timeline-tracker {
          display: grid;
          grid-template-columns: repeat(7, 1fr);
          gap: 8px;
        }

        .timeline-day {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 6px;
          padding: 8px 4px;
          border-radius: 10px;
          background: rgba(30, 41, 59, 0.4);
          border: 1px solid rgba(255, 255, 255, 0.06);
          transition: all 0.18s ease;
        }

        .timeline-day.is-current-day {
          border-color: rgba(245, 158, 11, 0.5);
          background: rgba(245, 158, 11, 0.08);
        }

        .timeline-day-label {
          font-size: 10px;
          font-weight: 700;
          color: #94a3b8;
          text-transform: uppercase;
        }

        .timeline-dot-circle {
          width: 22px;
          height: 22px;
          border-radius: 50%;
          display: grid;
          place-items: center;
          font-size: 10px;
          font-weight: 800;
          background: rgba(255, 255, 255, 0.08);
          color: #64748b;
        }

        .timeline-day.completed .timeline-dot-circle {
          background: #10b981;
          color: #05070e;
          box-shadow: 0 0 8px rgba(16, 185, 129, 0.6);
        }

        .timeline-day.missed .timeline-dot-circle {
          background: rgba(239, 68, 68, 0.2);
          color: #ef4444;
          border: 1px solid rgba(239, 68, 68, 0.4);
        }

        @media (max-width: 500px) {
          .daily-header-bar {
            padding: 16px;
          }
          .daily-scroll-area {
            padding: 16px;
          }
          .daily-modal-title {
            font-size: 1.35rem;
          }
          .streak-title-row {
            flex-direction: column;
            align-items: flex-start;
          }
        }
      `})]});return typeof document<`u`?(0,c.createPortal)(T,document.body):T}export{h as default,p as getTodaysChallenge,m as isDailyChallengeCompleted};