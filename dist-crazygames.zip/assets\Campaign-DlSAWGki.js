import{n as e,r as t,t as n}from"./jsx-runtime-DV-5N5dR.js";import{a as r,c as i,d as a,i as o,l as s,n as c,o as l,s as u,t as d}from"./index--8LujVWA.js";var f=t(),p=e(),m=n();function h({onPlayLevel:e,onBack:t,language:n}){let h=n===`tr`,g=(e,t)=>h?t:e,_=e=>e?h?e.tr:e.en:``,[v,y]=(0,f.useState)(1),[b,x]=(0,f.useState)(null),[S,C]=(0,f.useState)(()=>s(i(u.CAMPAIGN,{completedLevels:{}}))),[w,T]=(0,f.useState)(()=>{try{let e=c();return e.level||d(e.totalXP||0)}catch(e){return console.error(`Failed to load progression`,e),1}});(0,f.useEffect)(()=>{let e=e=>{if((!e.key||e.key===u.CAMPAIGN)&&C(s(i(u.CAMPAIGN,{completedLevels:{}}))),!e.key||e.key===`xo-tactix-progress`||e.key===u.PROGRESSION){let e=c();T(e.level||d(e.totalXP||0))}};return window.addEventListener(`storage`,e),()=>window.removeEventListener(`storage`,e)},[]),(0,f.useEffect)(()=>{let e=e=>{e.key===`Escape`&&(b?x(null):t())};return window.addEventListener(`keydown`,e),()=>window.removeEventListener(`keydown`,e)},[b,t]);let E=Object.values(S.completedLevels||{}).reduce((e,t)=>e+(t.stars||0),0),D=e=>l(e,S),O=e=>{if(!D(e)){typeof a==`function`&&a(`error`);return}typeof a==`function`&&a(`click`);let t=r(e);x(t)},k=()=>{b&&D(b.id)&&(typeof a==`function`&&a(`click`),e(b))},A=e=>{switch(e){case`easy`:return{label:g(`EASY`,`KOLAY`),color:`#10b981`,bg:`rgba(16, 185, 129, 0.15)`,border:`rgba(16, 185, 129, 0.4)`};case`medium`:return{label:g(`MEDIUM`,`ORTA`),color:`#00f0ff`,bg:`rgba(0, 240, 255, 0.15)`,border:`rgba(0, 240, 255, 0.4)`};case`hard`:return{label:g(`HARD`,`ZOR`),color:`#f59e0b`,bg:`rgba(245, 158, 11, 0.15)`,border:`rgba(245, 158, 11, 0.4)`};case`expert`:return{label:g(`EXPERT`,`UZMAN`),color:`#ef4444`,bg:`rgba(239, 68, 68, 0.18)`,border:`rgba(239, 68, 68, 0.5)`};default:return{label:g(`NORMAL`,`NORMAL`),color:`#00f0ff`,bg:`rgba(0, 240, 255, 0.15)`,border:`rgba(0, 240, 255, 0.4)`}}},j=(0,m.jsxs)(`div`,{className:`campaign-modal-backdrop`,onClick:t,children:[(0,m.jsxs)(`div`,{className:`campaign-modal-container`,onClick:e=>e.stopPropagation(),children:[(0,m.jsxs)(`header`,{className:`campaign-top-bar`,children:[(0,m.jsxs)(`div`,{className:`campaign-title-block`,children:[(0,m.jsxs)(`span`,{className:`campaign-badge`,children:[`🧩 `,g(`PUZZLE QUEST`,`BULMACA SEFERİ`)]}),(0,m.jsx)(`h2`,{className:`campaign-main-title`,children:g(`Tactical Conquest`,`Taktiksel Sefer`)})]}),(0,m.jsxs)(`div`,{className:`campaign-stats-group`,children:[(0,m.jsxs)(`div`,{className:`campaign-stat-pill xp-pill`,title:g(`Account Rank (Earned with XP)`,`Hesap Rütbesi (Kazanılan TP ile artar)`),children:[(0,m.jsx)(`span`,{className:`pill-icon`,children:`⚡`}),(0,m.jsx)(`span`,{className:`pill-val`,children:h?`RÜTBE ${w}`:`RANK ${w}`})]}),(0,m.jsxs)(`div`,{className:`campaign-stat-pill star-pill`,title:g(`Total Stars Collected`,`Kazanılan Yıldızlar`),children:[(0,m.jsx)(`span`,{className:`pill-icon`,children:`⭐`}),(0,m.jsxs)(`span`,{className:`pill-val`,children:[E,` / `,90]})]})]}),(0,m.jsx)(`button`,{type:`button`,className:`campaign-close-btn`,onClick:t,"aria-label":g(`Close`,`Kapat`),children:`✕`})]}),(0,m.jsxs)(`div`,{className:`campaign-scroll-body`,children:[(0,m.jsx)(`p`,{className:`campaign-subtext`,children:g(`Conquer handcrafted puzzle battles, master special powers, and collect stars to level up.`,`Özel bulmaca savaşlarını tamamla, güçleri ustalıkla kullan ve seviye atlamak için yıldızları topla.`)}),(0,m.jsx)(`div`,{className:`chapters-container`,children:o.map(e=>{let t=v===e.id,n=0,i=e.levels.length*3;e.levels.forEach(e=>{let t=S.completedLevels?.[e];t&&(n+=t.stars||0)});let o=Math.min(100,Math.round(n/i*100)),s=n===i;return(0,m.jsxs)(`div`,{className:`chapter-card ${t?`is-expanded`:``}`,children:[(0,m.jsxs)(`button`,{type:`button`,className:`chapter-header-btn`,onClick:()=>{typeof a==`function`&&a(`click`),y(t?null:e.id)},children:[(0,m.jsx)(`div`,{className:`chapter-icon-wrap`,children:e.icon}),(0,m.jsxs)(`div`,{className:`chapter-meta`,children:[(0,m.jsx)(`div`,{className:`chapter-num`,children:g(`CHAPTER ${e.id}`,`BÖLÜM ${e.id}`)}),(0,m.jsx)(`h3`,{className:`chapter-name`,children:_(e.title)})]}),(0,m.jsxs)(`div`,{className:`chapter-star-counter`,children:[(0,m.jsxs)(`span`,{className:`chapter-star-text`,children:[n,`/`,i,` ⭐`]}),(0,m.jsx)(`div`,{className:`chapter-progress-track`,children:(0,m.jsx)(`div`,{className:`chapter-progress-bar ${s?`is-gold`:``}`,style:{width:`${o}%`}})})]}),(0,m.jsx)(`span`,{className:`chapter-caret ${t?`rotated`:``}`,children:`▾`})]}),t&&(0,m.jsx)(`div`,{className:`chapter-levels-grid`,children:e.levels.map(e=>{let t=r(e),n=D(e),i=S.completedLevels?.[e],a=i?i.stars:0,o=A(t?.difficulty);return(0,m.jsxs)(`button`,{type:`button`,className:`level-card-btn ${n?``:`is-locked`} ${a>0?`is-beaten`:``}`,onClick:()=>O(e),disabled:!n,children:[(0,m.jsx)(`span`,{className:`level-difficulty-tag`,style:{color:o.color,backgroundColor:o.bg,borderColor:o.border},children:o.label}),(0,m.jsx)(`div`,{className:`level-number-display`,children:n?e:`🔒`}),(0,m.jsx)(`div`,{className:`level-stars-row`,children:[1,2,3].map(e=>(0,m.jsx)(`span`,{className:`star-symbol ${e<=a?`is-filled`:`is-empty`}`,children:`★`},e))})]},e)})})]},e.id)})})]})]}),b&&(0,m.jsx)(`div`,{className:`level-popup-backdrop`,onClick:()=>x(null),children:(0,m.jsxs)(`div`,{className:`level-popup-card`,onClick:e=>e.stopPropagation(),children:[(0,m.jsx)(`button`,{type:`button`,className:`level-popup-close`,onClick:()=>x(null),"aria-label":g(`Close`,`Kapat`),children:`✕`}),(0,m.jsxs)(`div`,{className:`level-popup-header`,children:[(0,m.jsxs)(`span`,{className:`level-popup-difficulty`,style:{color:A(b.difficulty).color,borderColor:A(b.difficulty).border,backgroundColor:A(b.difficulty).bg},children:[A(b.difficulty).label,` • `,b.boardSize,`x`,b.boardSize]}),(0,m.jsxs)(`h3`,{className:`level-popup-title`,children:[`#`,b.id,` `,_(b.title)]}),(0,m.jsx)(`p`,{className:`level-popup-desc`,children:_(b.description)})]}),(0,m.jsxs)(`div`,{className:`level-conditions-box`,children:[(0,m.jsx)(`div`,{className:`conditions-title`,children:g(`Star Objectives`,`Yıldız Hedefleri`)}),(0,m.jsxs)(`div`,{className:`condition-row`,children:[(0,m.jsx)(`span`,{className:`cond-star`,children:`★☆☆`}),(0,m.jsx)(`span`,{className:`cond-desc`,children:b.type===`puzzle`?g(`Puzzle: Solve the board`,`Bulmaca: Tahtayı çöz`):g(`Victory: Complete the match`,`Zafer: Maçı tamamlayıp kazan`)})]}),b.stars?.two&&(0,m.jsxs)(`div`,{className:`condition-row`,children:[(0,m.jsx)(`span`,{className:`cond-star`,children:`★★☆`}),(0,m.jsx)(`span`,{className:`cond-desc`,children:b.stars.two.condition===`win_in_moves`?b.stars.two.value===1?g(`Sharp mind: Win in 1 move`,`Keskin zeka: Tek hamlede kazan`):g(`Win in ${b.stars.two.value} moves or less`,`En fazla ${b.stars.two.value} hamlede kazan`):b.stars.two.condition===`power_used`?g(`Win using ${b.stars.two.value} power`,`${b.stars.two.value} gücünü kullanarak kazan`):b.stars.two.condition===`score_above`?g(`Win with 2x multiplier`,`2x Çarpanla kazan`):b.type===`puzzle`?g(`Tactical eye: Find the winning line`,`Taktiksel göz: Kazandıran hamleyi bul`):g(`Tactical mastery objective`,`Taktiksel ustalık hedefi`)})]}),b.stars?.three&&(0,m.jsxs)(`div`,{className:`condition-row`,children:[(0,m.jsx)(`span`,{className:`cond-star`,children:`★★★`}),(0,m.jsx)(`span`,{className:`cond-desc`,children:b.stars.three.condition===`win_in_moves`?b.stars.three.value===1?g(`Checkmate: Win in 1 move`,`Şah Mat: Tek hamlede bitir`):g(`Speed master: Win in ${b.stars.three.value} moves or less`,`Hız ustası: En fazla ${b.stars.three.value} hamlede kazan`):b.stars.three.condition===`score_above`?g(`Win with 3x multiplier`,`3x Çarpanla kazan`):g(`Grandmaster objective`,`Büyük usta hedefi`)})]})]}),b.reward&&(0,m.jsxs)(`div`,{className:`level-reward-row`,children:[(0,m.jsx)(`span`,{className:`reward-icon`,children:`🎁`}),(0,m.jsxs)(`span`,{className:`reward-info`,children:[g(`Reward:`,`Ödül:`),` `,(0,m.jsx)(`strong`,{children:b.reward.type===`skin`?h?`Tema: ${b.reward.value.toUpperCase()}`:`Theme: ${b.reward.value.toUpperCase()}`:b.reward.type===`power`?h?`Güç: ${b.reward.value.toUpperCase()}`:`Power: ${b.reward.value.toUpperCase()}`:`+${b.reward.value} XP`})]})]}),S.completedLevels?.[b.id]&&(0,m.jsxs)(`div`,{className:`best-score-banner`,children:[(0,m.jsxs)(`span`,{children:[`🏆 `,g(`Current Best:`,`En İyi Derecen:`)]}),(0,m.jsxs)(`strong`,{children:[S.completedLevels[b.id].stars,` / 3 ⭐`]})]}),(0,m.jsxs)(`button`,{type:`button`,className:`launch-mission-btn`,onClick:k,children:[(0,m.jsx)(`span`,{className:`launch-glow`}),(0,m.jsxs)(`span`,{className:`launch-text`,children:[`⚡ `,g(`START BATTLE`,`SAVAŞA BAŞLA`)]})]})]})}),(0,m.jsx)(`style`,{children:`
        .campaign-modal-backdrop {
          position: fixed;
          inset: 0;
          z-index: 9999;
          display: grid;
          place-items: center;
          background: rgba(3, 6, 15, 0.9);
          backdrop-filter: blur(14px);
          -webkit-backdrop-filter: blur(14px);
          padding: 16px;
          box-sizing: border-box;
          animation: campaignFadeIn 0.22s ease-out;
        }

        @keyframes campaignFadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .campaign-modal-container {
          position: relative;
          width: min(720px, 95vw);
          max-height: min(88vh, 760px);
          margin: auto;
          background: linear-gradient(180deg, rgba(17, 24, 39, 0.98) 0%, rgba(10, 14, 26, 0.99) 100%);
          border: 1px solid rgba(168, 85, 247, 0.35);
          border-radius: 24px;
          box-shadow: 0 25px 60px rgba(0, 0, 0, 0.85), 0 0 45px rgba(168, 85, 247, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.12);
          display: flex;
          flex-direction: column;
          overflow: hidden;
          box-sizing: border-box;
          animation: campaignPopUp 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes campaignPopUp {
          from { transform: scale(0.95) translateY(16px); opacity: 0; }
          to { transform: scale(1) translateY(0); opacity: 1; }
        }

        .campaign-top-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 18px 24px;
          border-bottom: 1px solid rgba(0, 240, 255, 0.15);
          background: rgba(15, 23, 42, 0.6);
          gap: 12px;
        }

        .campaign-badge {
          display: inline-block;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 1.5px;
          color: #a855f7;
          text-transform: uppercase;
          margin-bottom: 2px;
        }

        .campaign-main-title {
          margin: 0;
          font-size: 1.35rem;
          font-weight: 800;
          color: #ffffff;
          letter-spacing: 0.5px;
          text-shadow: 0 0 16px rgba(0, 240, 255, 0.4);
        }

        .campaign-stats-group {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-left: auto;
        }

        .campaign-stat-pill {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          border-radius: 999px;
          font-size: 0.85rem;
          font-weight: 700;
          border: 1px solid;
        }

        .xp-pill {
          background: rgba(168, 85, 247, 0.15);
          border-color: rgba(168, 85, 247, 0.4);
          color: #c084fc;
        }

        .star-pill {
          background: rgba(245, 158, 11, 0.15);
          border-color: rgba(245, 158, 11, 0.4);
          color: #fbbf24;
        }

        .campaign-close-btn {
          width: 34px;
          height: 34px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.2);
          background: rgba(255, 255, 255, 0.08);
          color: #ffffff;
          display: grid;
          place-items: center;
          cursor: pointer;
          font-size: 14px;
          transition: all 0.18s ease;
        }

        .campaign-close-btn:hover {
          background: rgba(239, 68, 68, 0.3);
          border-color: rgba(239, 68, 68, 0.6);
          color: #ff8888;
          transform: rotate(90deg);
        }

        .campaign-scroll-body {
          padding: 20px 24px 28px;
          overflow-y: auto;
          scrollbar-width: thin;
          scrollbar-color: rgba(0, 240, 255, 0.4) transparent;
        }

        .campaign-scroll-body::-webkit-scrollbar {
          width: 6px;
        }
        .campaign-scroll-body::-webkit-scrollbar-thumb {
          background: rgba(0, 240, 255, 0.35);
          border-radius: 3px;
        }

        .campaign-subtext {
          margin: 0 0 16px;
          font-size: 0.9rem;
          color: #94a3b8;
          line-height: 1.45;
        }

        .chapters-container {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .chapter-card {
          background: rgba(15, 23, 42, 0.7);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 16px;
          overflow: hidden;
          transition: border-color 0.2s, box-shadow 0.2s;
        }

        .chapter-card.is-expanded {
          border-color: rgba(0, 240, 255, 0.45);
          box-shadow: 0 0 24px rgba(0, 240, 255, 0.1);
        }

        .chapter-header-btn {
          width: 100%;
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 14px 18px;
          background: transparent;
          border: none;
          color: #fff;
          cursor: pointer;
          text-align: left;
          transition: background 0.18s;
        }

        .chapter-header-btn:hover {
          background: rgba(0, 240, 255, 0.05);
        }

        .chapter-icon-wrap {
          font-size: 1.6rem;
          line-height: 1;
          filter: drop-shadow(0 0 8px rgba(168, 85, 247, 0.5));
        }

        .chapter-meta {
          flex: 1;
          min-width: 0;
        }

        .chapter-num {
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 1.2px;
          color: #38bdf8;
          text-transform: uppercase;
        }

        .chapter-name {
          margin: 2px 0 0;
          font-size: 1.05rem;
          font-weight: 700;
          color: #f8fafc;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .chapter-star-counter {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 4px;
        }

        .chapter-star-text {
          font-size: 0.8rem;
          font-weight: 700;
          color: #fbbf24;
        }

        .chapter-progress-track {
          width: 80px;
          height: 6px;
          background: rgba(255, 255, 255, 0.1);
          border-radius: 999px;
          overflow: hidden;
        }

        .chapter-progress-bar {
          height: 100%;
          background: linear-gradient(90deg, #00f0ff, #38bdf8);
          border-radius: 999px;
          transition: width 0.3s ease;
        }

        .chapter-progress-bar.is-gold {
          background: linear-gradient(90deg, #f59e0b, #fbbf24);
          box-shadow: 0 0 8px rgba(245, 158, 11, 0.8);
        }

        .chapter-caret {
          font-size: 1.1rem;
          color: #64748b;
          transition: transform 0.22s ease;
        }

        .chapter-caret.rotated {
          transform: rotate(180deg);
          color: #00f0ff;
        }

        .chapter-levels-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
          gap: 10px;
          padding: 14px 18px 18px;
          background: rgba(4, 6, 14, 0.4);
          border-top: 1px solid rgba(255, 255, 255, 0.06);
        }

        .level-card-btn {
          position: relative;
          background: rgba(30, 41, 59, 0.5);
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 14px;
          padding: 14px 8px 10px;
          display: flex;
          flex-direction: column;
          align-items: center;
          cursor: pointer;
          transition: all 0.18s ease;
        }

        .level-card-btn:hover:not(:disabled) {
          border-color: #00f0ff;
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(0, 240, 255, 0.2);
          background: rgba(30, 41, 59, 0.85);
        }

        .level-card-btn:disabled {
          opacity: 0.45;
          cursor: not-allowed;
          filter: grayscale(80%);
        }

        .level-card-btn.is-beaten {
          border-color: rgba(245, 158, 11, 0.4);
          background: rgba(245, 158, 11, 0.05);
        }

        .level-difficulty-tag {
          position: absolute;
          top: 6px;
          right: 6px;
          font-size: 8px;
          font-weight: 800;
          padding: 2px 5px;
          border-radius: 6px;
          border: 1px solid;
          letter-spacing: 0.5px;
        }

        .level-number-display {
          font-size: 1.5rem;
          font-weight: 800;
          color: #ffffff;
          margin: 6px 0 4px;
          text-shadow: 0 0 10px rgba(0, 240, 255, 0.3);
        }

        .level-stars-row {
          display: flex;
          gap: 2px;
          font-size: 0.95rem;
        }

        .star-symbol.is-filled {
          color: #fbbf24;
          filter: drop-shadow(0 0 3px rgba(245, 158, 11, 0.9));
        }

        .star-symbol.is-empty {
          color: rgba(255, 255, 255, 0.18);
        }

        /* Popup Sub-modal */
        .level-popup-backdrop {
          position: fixed;
          inset: 0;
          z-index: 10001;
          display: grid;
          place-items: center;
          background: rgba(2, 4, 12, 0.85);
          backdrop-filter: blur(10px);
          padding: 16px;
          animation: campaignFadeIn 0.18s ease-out;
        }

        .level-popup-card {
          position: relative;
          width: min(440px, 94vw);
          margin: auto;
          background: #0f172a;
          border: 1.5px solid #a855f7;
          border-radius: 22px;
          padding: 24px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.85), 0 0 35px rgba(168, 85, 247, 0.3);
          animation: campaignPopUp 0.22s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .level-popup-close {
          position: absolute;
          top: 14px;
          right: 14px;
          width: 30px;
          height: 30px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.15);
          background: rgba(255, 255, 255, 0.08);
          color: #fff;
          cursor: pointer;
          display: grid;
          place-items: center;
        }

        .level-popup-header {
          margin-bottom: 16px;
        }

        .level-popup-difficulty {
          display: inline-block;
          font-size: 10px;
          font-weight: 800;
          padding: 3px 8px;
          border-radius: 8px;
          border: 1px solid;
          margin-bottom: 8px;
        }

        .level-popup-title {
          margin: 0 0 6px;
          font-size: 1.3rem;
          font-weight: 800;
          color: #fff;
        }

        .level-popup-desc {
          margin: 0;
          font-size: 0.9rem;
          color: #94a3b8;
          line-height: 1.4;
        }

        .level-conditions-box {
          background: rgba(0, 240, 255, 0.05);
          border: 1px solid rgba(0, 240, 255, 0.2);
          border-radius: 12px;
          padding: 12px 16px;
          margin-bottom: 16px;
        }

        .conditions-title {
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 1px;
          text-transform: uppercase;
          color: #38bdf8;
          margin-bottom: 8px;
        }

        .condition-row {
          display: flex;
          align-items: center;
          gap: 10px;
          font-size: 0.85rem;
          margin-bottom: 6px;
        }

        .condition-row:last-child {
          margin-bottom: 0;
        }

        .cond-star {
          font-size: 0.85rem;
          color: #fbbf24;
          font-weight: 700;
          min-width: 36px;
        }

        .cond-desc {
          color: #e2e8f0;
        }

        .level-reward-row {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 12px;
          background: rgba(168, 85, 247, 0.12);
          border: 1px solid rgba(168, 85, 247, 0.35);
          border-radius: 10px;
          font-size: 0.85rem;
          color: #c084fc;
          margin-bottom: 12px;
        }

        .level-reward-row strong {
          color: #f8fafc;
        }

        .best-score-banner {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 10px 14px;
          background: rgba(245, 158, 11, 0.12);
          border: 1px solid rgba(245, 158, 11, 0.35);
          border-radius: 10px;
          font-size: 0.85rem;
          color: #fbbf24;
          margin-bottom: 16px;
        }

        .launch-mission-btn {
          position: relative;
          width: 100%;
          padding: 14px;
          border-radius: 14px;
          border: none;
          background: linear-gradient(135deg, #00f0ff 0%, #0284c7 100%);
          color: #030712;
          font-size: 1.05rem;
          font-weight: 900;
          letter-spacing: 1px;
          cursor: pointer;
          overflow: hidden;
          transition: transform 0.16s ease, box-shadow 0.16s ease;
          box-shadow: 0 4px 20px rgba(0, 240, 255, 0.4);
        }

        .launch-mission-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 28px rgba(0, 240, 255, 0.6);
        }

        .launch-mission-btn:active {
          transform: translateY(0);
        }

        @media (max-width: 500px) {
          .campaign-top-bar {
            padding: 14px 16px;
          }
          .campaign-scroll-body {
            padding: 16px;
          }
          .chapter-levels-grid {
            grid-template-columns: repeat(auto-fill, minmax(85px, 1fr));
            gap: 8px;
            padding: 10px;
          }
          .level-number-display {
            font-size: 1.25rem;
          }
        }
      `})]});return typeof document<`u`?(0,p.createPortal)(j,document.body):j}export{h as default};